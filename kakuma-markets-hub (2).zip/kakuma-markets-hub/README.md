# Kakuma Markets Hub — Dashboard starter

## Open in VS Code
1. Extract `kakuma-markets-hub.zip`.
2. Open VS Code → File → Open Folder → select `kakuma-markets-hub`.
3. Install the **Live Server** extension (by Ritwick Dey).
4. Right-click `index.html` → **Open with Live Server**.

You can also double-click `index.html` to open it in a browser, but Live Server is recommended.

## Included
- Responsive dashboard overview with colorful KPI cards and charts
- Business directory: search, category filter, add and remove businesses
- Product catalogue: add products
- Customer insights and analytics pages
- CSV export for business, product and summary reports
- Workspace settings
- Browser local storage for records added on this device

## Important
This is a frontend prototype with illustrative/sample metrics and sample businesses. Records added are saved only in the current browser on this device. It does not yet have user accounts, a shared online database, real customer tracking, or a public marketplace. Those require a backend/API and database such as Supabase or Firebase. Chart.js is loaded from a CDN, so an internet connection is needed for charts.
