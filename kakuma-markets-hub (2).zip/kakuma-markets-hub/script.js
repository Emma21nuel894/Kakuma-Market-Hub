const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const seedBusinesses=[
{name:"Amina Fashion House",category:"Fashion",location:"Kakuma 1",phone:"0712 345 678",views:2840,color:"purple"},
{name:"Kakuma Fresh Mart",category:"Food & Grocery",location:"Kakuma 2",phone:"0723 456 789",views:2310,color:"green"},
{name:"TechPoint Electronics",category:"Electronics",location:"Kakuma 1",phone:"0701 234 567",views:1980,color:"blue"},
{name:"Grace Beauty Studio",category:"Beauty",location:"Kakuma 3",phone:"0798 765 432",views:1740,color:"orange"},
{name:"Unity Shoe Centre",category:"Fashion",location:"Kakuma 2",phone:"0711 223 344",views:1510,color:"purple"},
{name:"Mama's Kitchen",category:"Food & Grocery",location:"Kakuma 1",phone:"0722 334 455",views:1390,color:"orange"},
{name:"Digital Skills Corner",category:"Services",location:"Kakuma 3",phone:"0700 111 222",views:1120,color:"blue"},
{name:"Bright Home Supplies",category:"Services",location:"Kakuma 2",phone:"0733 444 555",views:980,color:"green"}
];
const seedProducts=[
{name:"Classic everyday sneakers",category:"Fashion",price:2500,seller:"Unity Shoe Centre",emoji:"👟"},
{name:"Fresh fruit & grocery pack",category:"Food & Grocery",price:850,seller:"Kakuma Fresh Mart",emoji:"🥑"},
{name:"Wireless headphones",category:"Electronics",price:1800,seller:"TechPoint Electronics",emoji:"🎧"},
{name:"Natural hair care set",category:"Beauty",price:1200,seller:"Grace Beauty Studio",emoji:"🧴"},
{name:"Casual cotton shirt",category:"Fashion",price:950,seller:"Amina Fashion House",emoji:"👕"},
{name:"Home kitchen essentials",category:"Services",price:1600,seller:"Bright Home Supplies",emoji:"🛍️"}
];
let businesses=JSON.parse(localStorage.getItem('kmh_businesses')||'null')||seedBusinesses;
let products=JSON.parse(localStorage.getItem('kmh_products')||'null')||seedProducts;
const save=()=>{localStorage.setItem('kmh_businesses',JSON.stringify(businesses));localStorage.setItem('kmh_products',JSON.stringify(products));};
const fmt=n=>Number(n).toLocaleString('en-KE');
function showToast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2600)}
function initials(n){return n.split(/\s+/).slice(0,2).map(x=>x[0]).join('').toUpperCase()}
function renderBusinesses(){
 const body=$('#businessTable');if(!body)return;
 const term=($('#businessSearch')?.value||'').toLowerCase(),cat=$('#categoryFilter')?.value||'All';
 const filtered=businesses.filter(b=>(b.name+' '+b.location+' '+b.phone).toLowerCase().includes(term)&&(cat==='All'||b.category===cat));
 $('#businessResultsCount').textContent=`${filtered.length} businesses`;
 body.innerHTML=filtered.map((b,i)=>`<tr><td><div class="business-cell"><span class="business-avatar ${b.color||'purple'}">${initials(b.name)}</span>${escapeHtml(b.name)}</div></td><td>${escapeHtml(b.location)}</td><td>${escapeHtml(b.category)}</td><td>${escapeHtml(b.phone)}</td><td>${fmt(b.views||0)}</td><td><span class="status-pill">Active</span></td><td><button class="row-action" data-delete="${businesses.indexOf(b)}">Remove</button></td></tr>`).join('')||'<tr><td colspan="7">No businesses match your search.</td></tr>';
 $('#businessNavCount').textContent=businesses.length;
 $('#totalBusinesses').textContent=fmt(248+businesses.length-seedBusinesses.length);
 $('#popularBusinesses').innerHTML=[...businesses].sort((a,b)=>(b.views||0)-(a.views||0)).slice(0,4).map(b=>`<tr><td><div class="business-cell"><span class="business-avatar ${b.color||'purple'}">${initials(b.name)}</span>${escapeHtml(b.name)}</div></td><td>${escapeHtml(b.category)}</td><td>${fmt(b.views||0)}</td><td><span class="status-pill">Active</span></td></tr>`).join('');
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function renderProducts(){
 $('#productCountPage').textContent=fmt(1486+products.length-seedProducts.length);
 $('#totalProducts').textContent=fmt(1486+products.length-seedProducts.length);
 $('#productGrid').innerHTML=products.map(p=>`<div class="product-card"><div class="product-art">${p.emoji||'📦'}</div><strong>${escapeHtml(p.name)}</strong><p>${escapeHtml(p.category)} · ${escapeHtml(p.seller)}</p><span class="product-price">KSh ${fmt(p.price)}</span></div>`).join('');
}
function renderAll(){renderBusinesses();renderProducts();$('#totalBusinesses').textContent=fmt(248+businesses.length-seedBusinesses.length)}
function navigate(page){
 $$('.page-content').forEach(p=>p.classList.add('hidden'));$('#'+page+'Page')?.classList.remove('hidden');
 $$('.nav-link').forEach(b=>b.classList.toggle('active',b.dataset.page===page));
 $('#breadcrumbPage').textContent=page.charAt(0).toUpperCase()+page.slice(1);$('#sidebar').classList.remove('open');
 if(page==='customers')setTimeout(makeChannelChart,30);if(page==='analytics')setTimeout(makeAnalyticsCharts,30);
 window.scrollTo({top:0,behavior:'smooth'});
}
$$('.nav-link').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.page)));
$$('[data-goto]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.goto)));
$('#mobileMenu').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
$('#businessSearch').addEventListener('input',renderBusinesses);$('#categoryFilter').addEventListener('change',renderBusinesses);
function openModal(id){$('#'+id).classList.remove('hidden')}
$$('[data-close]').forEach(b=>b.addEventListener('click',()=>$('#'+b.dataset.close).classList.add('hidden')));
$('#addBusinessBtn').onclick=()=>openModal('businessModal');$('#addBusinessTop').onclick=()=>openModal('businessModal');$('#addProductBtn').onclick=()=>openModal('productModal');
$('#businessForm').addEventListener('submit',e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));businesses.unshift({...d,views:0,color:['purple','blue','green','orange'][Math.floor(Math.random()*4)]});save();renderAll();e.target.reset();$('#businessModal').classList.add('hidden');showToast('Business added to your directory')});
$('#productForm').addEventListener('submit',e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));products.unshift({...d,price:Number(d.price),emoji:'📦'});save();renderProducts();e.target.reset();$('#productModal').classList.add('hidden');showToast('Product added to your catalogue')});
$('#businessTable').addEventListener('click',e=>{const i=e.target.dataset.delete;if(i!==undefined&&confirm('Remove this business from your local directory?')){businesses.splice(Number(i),1);save();renderAll();showToast('Business removed')}});
let activityChart,categoryChart,channelChart,weeklyChart,enquiryChart;
const chartFont={family:'DM Sans',size:10};
function makeActivityChart(){if(activityChart)activityChart.destroy();activityChart=new Chart($('#activityChart'),{type:'line',data:{labels:['Oct 3','Oct 7','Oct 11','Oct 15','Oct 19','Oct 23','Oct 27','Nov 1'],datasets:[{label:'Visits',data:[980,1280,1190,1540,1420,1810,1690,2140],borderColor:'#8062e9',backgroundColor:'rgba(128,98,233,.10)',fill:true,tension:.4,pointRadius:2,pointBackgroundColor:'#8062e9',borderWidth:2},{label:'Enquiries',data:[320,390,360,510,470,590,560,720],borderColor:'#36c49b',backgroundColor:'rgba(54,196,155,.05)',fill:true,tension:.4,pointRadius:2,borderWidth:2}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{grid:{display:false},ticks:{color:'#aaa',font:chartFont}},y:{beginAtZero:true,grid:{color:'#f1f1f6'},ticks:{color:'#aaa',font:chartFont}}}}})}
function makeCategoryChart(){if(categoryChart)categoryChart.destroy();categoryChart=new Chart($('#categoryChart'),{type:'doughnut',data:{labels:['Fashion','Food & Grocery','Electronics','Beauty','Services'],datasets:[{data:[29,24,18,13,16],backgroundColor:['#8062e9','#43a0ed','#f4a65c','#39c49b','#f17e9a'],borderWidth:0,hoverOffset:5}]},options:{cutout:'75%',responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}}}});const colors=['#8062e9','#43a0ed','#f4a65c','#39c49b','#f17e9a'];$('#categoryLegend').innerHTML=['Fashion','Food & Grocery','Electronics','Beauty','Services'].map((x,i)=>`<div><i style="background:${colors[i]}"></i>${x}</div>`).join('')}
function makeChannelChart(){if(channelChart||!$('#channelChart'))return;channelChart=new Chart($('#channelChart'),{type:'bar',data:{labels:['WhatsApp','Phone call','Marketplace','Walk-in'],datasets:[{label:'Enquiries',data:[48,24,18,10],backgroundColor:['#8062e9','#43a0ed','#39c49b','#f4a65c'],borderRadius:6,borderSkipped:false}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{grid:{display:false},ticks:{font:chartFont,color:'#999'}},y:{grid:{color:'#f1f1f6'},ticks:{font:chartFont,color:'#999'}}}}})}
function makeAnalyticsCharts(){if(weeklyChart||!$('#weeklyChart'))return;weeklyChart=new Chart($('#weeklyChart'),{type:'bar',data:{labels:['Week 1','Week 2','Week 3','Week 4'],datasets:[{label:'Visits',data:[3200,4100,3850,5200],backgroundColor:'#8062e9',borderRadius:6}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{grid:{display:false},ticks:{font:chartFont}},y:{grid:{color:'#f1f1f6'},ticks:{font:chartFont}}}}});enquiryChart=new Chart($('#enquiryChart'),{type:'bar',data:{labels:['Fashion','Food','Electronics','Beauty','Services'],datasets:[{label:'Enquiries',data:[280,220,170,125,141],backgroundColor:['#8062e9','#43a0ed','#f4a65c','#39c49b','#f17e9a'],borderRadius:5}]},options:{indexAxis:'y',responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{grid:{color:'#f1f1f6'},ticks:{font:chartFont}},y:{grid:{display:false},ticks:{font:chartFont}}}}})}
function downloadCSV(filename,rows){const csv=rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'}));a.download=filename;a.click();URL.revokeObjectURL(a.href);showToast('Your CSV report is ready')}
const businessRows=()=>[['Business','Category','Location','Phone','Views'],...businesses.map(b=>[b.name,b.category,b.location,b.phone,b.views])];
const productRows=()=>[['Product','Category','Price KSh','Seller'],...products.map(p=>[p.name,p.category,p.price,p.seller])];
$('#exportBusinesses').onclick=()=>downloadCSV('kakuma-businesses.csv',businessRows());$('#exportProducts').onclick=()=>downloadCSV('kakuma-products.csv',productRows());$('#exportAnalytics').onclick=()=>downloadCSV('kakuma-businesses.csv',businessRows());$('#exportSummary').onclick=()=>downloadCSV('kakuma-market-summary.csv',[['Metric','Value'],['Businesses',businesses.length],['Products',products.length],['Sample customer visits',18642],['Sample enquiries',936]]);
$('#viewAnalyticsBtn').onclick=()=>navigate('analytics');$('#learnMoreBtn').onclick=()=>navigate('businesses');$('#notificationBtn').onclick=()=>showToast('You are all caught up!');
$('#saveSettings').onclick=()=>{localStorage.setItem('kmh_workspace_name',$('#workspaceName').value);localStorage.setItem('kmh_tagline',$('#workspaceTagline').value);$('#settingsMessage').textContent='Workspace settings saved in this browser.';showToast('Settings saved')};
$('#periodFilter').onchange=e=>{const n=e.target.value;const vals=n==='7'?[220,340,310,430,390,520,610]:n==='90'?[650,780,820,960,1120,1280,1450,1690]:[980,1280,1190,1540,1420,1810,1690,2140];if(activityChart){activityChart.data.datasets[0].data=vals;activityChart.data.datasets[1].data=vals.map(v=>Math.round(v*.34));activityChart.update()}showToast('Showing the last '+n+' days')};
renderAll();makeActivityChart();makeCategoryChart();
